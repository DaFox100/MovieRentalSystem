package com.movierental;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;

public class MoviesServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Set the response content type
        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");
        
        // The string we want to send to JavaScript
        String message = "\"<h1>Welcome to the Movie Rental System!</h1>\"";
        
        // Write the string to the response
        response.getWriter().write(message);
    }
}
